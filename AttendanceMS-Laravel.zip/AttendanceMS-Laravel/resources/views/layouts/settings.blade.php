<div class="page-title-box">
    <div class="row align-items-center">
         @yield('breadcrumb')
            <div class="col-sm-6">
                <div class="float-right d-none d-md-block">
                     <div class="">
                        @yield('button')
                     </div>
                 </div>
            </div>
    </div>
</div>
<!-- end row -->




