<div class="page-title-box">
    <div class="row align-items-center">
         <?php echo $__env->yieldContent('breadcrumb'); ?>
            <div class="col-sm-6">
                <div class="float-right d-none d-md-block">
                     <div class="">
                        <?php echo $__env->yieldContent('button'); ?>
                     </div>
                 </div>
            </div>
    </div>
</div>
<!-- end row -->




<?php /**PATH D:\XAMPP\htdocs\AttendanceMS-Laravel\resources\views/layouts/settings.blade.php ENDPATH**/ ?>